------------------------------------------------------
BehaviorBricks - Behavior Trees for Unity v.1.0.2
------------------------------------------------------

For a quick start with Behavior Bricks go to

http://bb.padaonegames.com/doku.php?id=quick:design

and follow the quick start guide. For even a quicker one you can check the folder

BehaviorBricks/Samples/QuickStartGuide/Done/DoneScene 

to play the final scene as configured in the start guide.

More examples in the BehaviorBricks/Samples folder, and for complete documentation, examples and information visit: 

http://bb.padaonegames.com
